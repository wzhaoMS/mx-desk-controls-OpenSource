// Long-lived bridge process for both devices. Holds the Keypad keepalive so
// its display and input stream stay alive, and diverts the Keypad nav buttons
// and the Dialpad rollers.
//
// Commands arrive on stdin or on a unix socket, /tmp/mx-creative-console.sock
// or $MXCC_SOCKET. Hammerspoon must use the socket: hs.task:setInput only
// delivers before start(), and silently drops everything after.
//
// commands:
//   paint <key 0-8> <byteLen>\n      followed by byteLen raw JPEG bytes
//   paintpng <key 0-8> <byteLen>\n   same, PNG, converted here
//   brightness <0-100>\n
//   quit\n
// events, to stdout and to a connected socket client:
//   ready
//   key <1-9>            LCD key down
//   key up               all LCD keys released
//   nav left|right       page arrow down
//   nav up               page arrows released
//   dial <0|1> <delta>   roller 1 is the large dial, 0 the small wheel
//   dialkey <1-4>        Dialpad button down
//   dialkey up           Dialpad buttons released
//   ping                 every 10 s, to a socket client only
#include <CoreFoundation/CoreFoundation.h>
#include <CoreGraphics/CoreGraphics.h>
#include <ImageIO/ImageIO.h>
#include <IOKit/hid/IOHIDManager.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <limits.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/un.h>

#define VID 0x046D
#define PID_KEYPAD  0xC354
#define PID_DIALPAD 0xBC00
#define MAX_PACKET 4095
#define MAX_JPEG 300000
#define IDX_0008 0x04   // KeepAlive, Keypad
#define IDX_1B04 0x0b   // ReprogControlsV4, Keypad
#define IDX_8040 0x0f   // BrightnessControl, Keypad
#define IDX_4610 0x0d   // MultiRoller, Dialpad
#define IDX_1B04_DIAL 0x0a   // ReprogControlsV4, Dialpad
#define CID_LEFT  0x01a1
#define CID_RIGHT 0x01a2
#define ROLLERS 2

// The Dialpad's four buttons, all divertable (getCidInfo flags 0x31).
static const uint16_t kDialCids[4] = { 0x0053, 0x0056, 0x0059, 0x005a };

#define KEY_W 118
#define KEY_H 118
#define ORIGIN_X 23
#define ORIGIN_Y 6
#define PITCH 158

static IOHIDDeviceRef gKeypad = NULL;
static IOHIDDeviceRef gDialpad = NULL;
static int gBrightness = 100;
static int gClientFd = -1;
static char gReady[64] = "ready\n";
static CFFileDescriptorRef gClientCF = NULL;
static void dropClient(void);

// Events go to stdout and to a connected socket client, so the shell workflow
// and a socket consumer both work.
static void emit(const char *fmt, ...) {
    char line[128];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(line, sizeof line, fmt, ap);
    va_end(ap);
    if (n <= 0) return;
    fputs(line, stdout);
    fflush(stdout);
    if (gClientFd >= 0 && write(gClientFd, line, (size_t)n) < 0) {
        // EAGAIN on a non-blocking socket means the buffer is full, not that
        // the peer is gone. Dropping the client there loses the connection for
        // no reason, and it fails silently at both ends.
        if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
            // Closing the descriptor alone leaves the run loop source scheduled
            // against it, and the fd number can be reused before the eventual
            // invalidate closes it a second time.
            dropClient();
        }
    }
}

// A device that went away leaves its global NULL while timers and the command
// channel keep running, so every write has to tolerate it.
static void send11(IOHIDDeviceRef dev, uint8_t featIdx, uint8_t func,
                   uint8_t p0, uint8_t p1, uint8_t p2) {
    if (!dev) return;
    uint8_t b[20];
    memset(b, 0, sizeof b);
    b[0] = 0x11; b[1] = 0xFF; b[2] = featIdx;
    b[3] = (uint8_t)((func << 4) | 0x01);
    b[4] = p0; b[5] = p1; b[6] = p2;
    IOHIDDeviceSetReport(dev, kIOHIDReportTypeOutput, 0x11, b, sizeof b);
}

static void setBrightness(int pct) {
    if (!gKeypad) return;
    uint8_t b[20];
    memset(b, 0, sizeof b);
    b[0] = 0x11; b[1] = 0xFF; b[2] = IDX_8040; b[3] = 0x2b; b[4] = 0x00; b[5] = (uint8_t)pct;
    IOHIDDeviceSetReport(gKeypad, kIOHIDReportTypeOutput, 0x11, b, sizeof b);
}

static uint8_t seqByte(int index, int isFirst, int isLast) {
    uint8_t v = (uint8_t)(index | 0x20);
    if (isFirst) v |= 0x80;
    if (isLast)  v |= 0x40;
    return v;
}
static void put16(uint8_t *p, int off, uint16_t v) {
    p[off] = (uint8_t)(v >> 8); p[off + 1] = (uint8_t)(v & 0xFF);
}

// Hammerspoon hands back PNG, since hs.image has no JPEG encoder. ImageIO is
// already linked for the paint path, so the conversion belongs here.
//
// The frame header declares KEY_W by KEY_H, so the JPEG has to match or the
// device renders nothing. hs.canvas draws at the screen's backing scale, so a
// 118-point tile arrives as a 236 px 16-bit RGBA PNG. Redrawing into an 8-bit
// RGB context at key size normalises size, depth and alpha in one step.
static CFDataRef pngToJpeg(const uint8_t *png, size_t len) {
    CFDataRef src = CFDataCreate(NULL, png, (CFIndex)len);
    CGImageSourceRef is = CGImageSourceCreateWithData(src, NULL);
    CGImageRef img = is ? CGImageSourceCreateImageAtIndex(is, 0, NULL) : NULL;
    CFMutableDataRef out = NULL;
    if (img) {
        CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
        CGContextRef ctx = CGBitmapContextCreate(NULL, KEY_W, KEY_H, 8, 0, cs,
                                                 kCGImageAlphaNoneSkipLast);
        CGContextDrawImage(ctx, CGRectMake(0, 0, KEY_W, KEY_H), img);
        CGImageRef flat = CGBitmapContextCreateImage(ctx);

        // Quality 0.85, multi-packet when the frame is bigger than one packet.
        // The continuation path is proven: app icons at this quality span two
        // to three packets and rendered. Julusian ships quality 95 and the
        // same fragmentation, byte for byte.
        out = CFDataCreateMutable(kCFAllocatorDefault, 0);
        CGImageDestinationRef dst =
            CGImageDestinationCreateWithData(out, CFSTR("public.jpeg"), 1, NULL);
        const void *keys[] = { kCGImageDestinationLossyCompressionQuality };
        double q = 0.85;
        CFNumberRef qn = CFNumberCreate(kCFAllocatorDefault, kCFNumberDoubleType, &q);
        const void *vals[] = { qn };
        CFDictionaryRef opts = CFDictionaryCreate(kCFAllocatorDefault, keys, vals, 1,
                                                  &kCFTypeDictionaryKeyCallBacks,
                                                  &kCFTypeDictionaryValueCallBacks);
        CGImageDestinationAddImage(dst, flat, opts);
        CGImageDestinationFinalize(dst);
        CFRelease(opts); CFRelease(qn); CFRelease(dst);
        CGImageRelease(flat); CGContextRelease(ctx); CGColorSpaceRelease(cs);
        CGImageRelease(img);
    }
    if (is) CFRelease(is);
    CFRelease(src);
    return out;
}

// The firmware reclaims the panel after a stretch of inactivity even while the
// keepalive and brightness are held, so the last frame per key is kept and
// re-sent on a timer. A repaint does take the display back.
static uint8_t *gLast[9];
static size_t gLastLen[9];

static void paintKey(int keyIndex, const uint8_t *jp, size_t jlen);

static void refreshCB(CFRunLoopTimerRef t, void *info) {
    (void)t; (void)info;
    int n = 0;
    for (int i = 0; i < 9; i++)
        if (gLast[i]) { paintKey(i, gLast[i], gLastLen[i]); n++; }
    fprintf(stderr, "refresh %d keys\n", n);
}

// paintfile takes a path from the command channel. Confine it to the render
// directory so a stray client cannot use the LCD as an oracle for arbitrary
// files, and so a FIFO or device node cannot wedge the run loop.
static int pathIsAllowed(const char *path) {
    const char *home = getenv("HOME");
    if (!home) return 0;
    char root[PATH_MAX], resolved[PATH_MAX];
    const char *sub = getenv("MXCC_IMAGE_DIR");
    if (sub) {
        if (!realpath(sub, root)) return 0;
    } else {
        char raw[PATH_MAX];
        snprintf(raw, sizeof raw, "%s/.hammerspoon", home);
        if (!realpath(raw, root)) return 0;
    }
    if (!realpath(path, resolved)) return 0;
    size_t n = strlen(root);
    return strncmp(resolved, root, n) == 0 && (resolved[n] == '/' || resolved[n] == '\0');
}

static void paintKey(int keyIndex, const uint8_t *jp, size_t jlen) {
    // The frame header carries the length in 16 bits, so anything larger would
    // be silently truncated and render as garbage.
    if (jlen > 0xFFFF) {
        fprintf(stderr, "paintKey %d: frame %zu bytes exceeds 65535, dropped\n", keyIndex, jlen);
        return;
    }
    if (jp != gLast[keyIndex]) {
        uint8_t *grown = realloc(gLast[keyIndex], jlen);
        if (!grown) {
            fprintf(stderr, "paintKey %d: out of memory, keeping previous frame\n", keyIndex);
            return;
        }
        gLast[keyIndex] = grown;
        memcpy(gLast[keyIndex], jp, jlen);
        gLastLen[keyIndex] = jlen;
    }
    // Cached above regardless, so an unplugged Keypad still repaints on return.
    if (!gKeypad) return;
    int col = keyIndex % 3, row = keyIndex / 3;
    uint16_t px = (uint16_t)(ORIGIN_X + col * PITCH);
    uint16_t py = (uint16_t)(ORIGIN_Y + row * PITCH);

    static uint8_t pkt[MAX_PACKET];
    memset(pkt, 0, sizeof pkt);
    size_t n1 = jlen < (MAX_PACKET - 20) ? jlen : (MAX_PACKET - 20);
    memcpy(pkt + 20, jp, n1);
    pkt[0] = 0x14; pkt[1] = 0xFF; pkt[2] = 0x02; pkt[3] = 0x2b;
    pkt[4] = seqByte(1, 1, n1 >= jlen);
    put16(pkt, 5, 0x0100);
    put16(pkt, 7, 0x0100);
    put16(pkt, 9,  px);
    put16(pkt, 11, py);
    put16(pkt, 13, KEY_W);
    put16(pkt, 15, KEY_H);
    put16(pkt, 18, (uint16_t)jlen);
    IOReturn rc = IOHIDDeviceSetReport(gKeypad, kIOHIDReportTypeOutput, 0x14, pkt, MAX_PACKET);
    if (rc != kIOReturnSuccess)
        fprintf(stderr, "paint key %d packet 1 rc=0x%08x\n", keyIndex, rc);

    size_t remaining = jlen - n1;
    for (int part = 2; remaining > 0; part++) {
        // The firmware needs a moment to take a fragment before the next one
        // arrives. Back-to-back writes render only intermittently, which is
        // why icons appeared during timer-driven repaints and never on a
        // one-shot paint. Node implementations get this pacing for free from
        // their event loop.
        usleep(5000);
        memset(pkt, 0, sizeof pkt);
        size_t cnt = remaining < (MAX_PACKET - 5) ? remaining : (MAX_PACKET - 5);
        size_t off = jlen - remaining;
        remaining -= cnt;
        memcpy(pkt + 5, jp + off, cnt);
        pkt[0] = 0x14; pkt[1] = 0xFF; pkt[2] = 0x02; pkt[3] = 0x2b;
        pkt[4] = seqByte(part, 0, remaining == 0);
        IOReturn crc = IOHIDDeviceSetReport(gKeypad, kIOHIDReportTypeOutput, 0x14, pkt, MAX_PACKET);
        if (crc != kIOReturnSuccess)
            fprintf(stderr, "paint key %d packet %d rc=0x%08x\n", keyIndex, part, crc);
    }
}

// Report 0x13 repeats the pressed list for as long as a key is held, and the
// 0x1B04 notification behaves the same way. Emitting every repeat floods the
// socket, so only a change of state goes out.
static int gHeldKey = 0;
static uint16_t gHeldCid = 0;

static void keypadCB(void *c, IOReturn r, void *s, IOHIDReportType t,
                     uint32_t rid, uint8_t *rep, CFIndex len) {
    (void)c;(void)r;(void)s;(void)t;
    if (rid == 0x11 && len > 5) {
        if (rep[3] != 0x00) return;             // our own ack coming back
        if (rep[2] != IDX_1B04) return;         // heartbeat and the rest
        uint16_t cid = (uint16_t)((rep[4] << 8) | rep[5]);
        if (cid == gHeldCid) return;
        gHeldCid = cid;
        if (cid == CID_LEFT)       emit("nav left\n");
        else if (cid == CID_RIGHT) emit("nav right\n");
        else                       emit("nav up\n");
    } else if (rid == 0x13 && len > 6) {
        // Same trap as 0x11: byte 3 carries the function-and-software-id we
        // sent, so anything non-zero is our own write echoing back. Reading
        // those as presses fired key 1 roughly every five seconds, which drove
        // whatever that key was bound to.
        if (rep[3] != 0x00) return;
        int key = rep[6];
        if (key == gHeldKey) return;
        gHeldKey = key;
        if (key != 0x00) emit("key %d\n", key);
        else             emit("key up\n");
    }
}

static uint16_t gHeldDial[4] = { 0, 0, 0, 0 };

static int dialIndex(uint16_t cid) {
    for (int i = 0; i < 4; i++)
        if (cid == kDialCids[i]) return i + 1;
    return 0;
}

static int inSet(const uint16_t *set, uint16_t cid) {
    for (int i = 0; i < 4; i++) if (set[i] == cid) return 1;
    return 0;
}

static void dialpadCB(void *c, IOReturn r, void *s, IOHIDReportType t,
                      uint32_t rid, uint8_t *rep, CFIndex len) {
    (void)c;(void)r;(void)s;(void)t;
    if (rid != 0x11 || len < 6 || rep[3] != 0x00) return;
    if (rep[2] == IDX_4610) {
        emit("dial %d %d\n", rep[4], (int)(int8_t)rep[5]);
        return;
    }
    if (rep[2] == IDX_1B04_DIAL) {
        // The notification lists every diverted button currently down, so press
        // and release have to come from comparing sets. Reading only the first
        // slot reports a release when a second button is added to the list,
        // which cuts a push-to-talk chord short.
        uint16_t now[4] = { 0, 0, 0, 0 };
        int slots = (int)((len - 4) / 2);
        if (slots > 4) slots = 4;
        for (int i = 0; i < slots; i++)
            now[i] = (uint16_t)((rep[4 + i * 2] << 8) | rep[5 + i * 2]);

        if (memcmp(gHeldDial, now, sizeof now) == 0) return;   // repeats while held

        for (int i = 0; i < 4; i++) {
            int n = gHeldDial[i] && !inSet(now, gHeldDial[i]) ? dialIndex(gHeldDial[i]) : 0;
            if (n) emit("dialkey %d up\n", n);
        }
        for (int i = 0; i < 4; i++) {
            int n = now[i] && !inSet(gHeldDial, now[i]) ? dialIndex(now[i]) : 0;
            if (n) emit("dialkey %d\n", n);
        }
        memcpy(gHeldDial, now, sizeof now);
        if (!now[0] && !now[1] && !now[2] && !now[3]) emit("dialkey up\n");
    }
}

// SIGTERM must unwind rather than kill the process outright. Terminating
// immediately leaves the Dialpad's rollers and buttons diverted with nothing
// listening, so the dial goes mute until something restores them or the device
// power cycles. launchctl and pkill both send SIGTERM.
//
// CFRunLoopStop is not async-signal-safe, so the handler only writes a byte,
// which is, and the run loop stops itself once it services the read end.
static int gSigPipe[2] = { -1, -1 };

static void onSignal(int sig) {
    unsigned char b = (unsigned char)sig;
    ssize_t n = write(gSigPipe[1], &b, 1);
    (void)n;
}

static void sigPipeCB(CFFileDescriptorRef f, CFOptionFlags cb, void *info) {
    (void)cb; (void)info;
    unsigned char b;
    while (read(CFFileDescriptorGetNativeDescriptor(f), &b, 1) == 1) { }
    CFRunLoopStop(CFRunLoopGetMain());
}

static void keepaliveCB(CFRunLoopTimerRef t, void *info) {
    (void)t; (void)info;
    send11(gKeypad, IDX_0008, 1, 0x0b, 0xb8, 0x00);
}

// A client cannot tell a dead socket from an idle one, because the helper only
// speaks when the device is touched. This gives it something to time out on.
// Client only, so it does not fill the log.
static void pingCB(CFRunLoopTimerRef t, void *info) {
    (void)t; (void)info;
    if (gClientFd < 0) return;
    if (write(gClientFd, "ping\n", 5) < 0 &&
        errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
        dropClient();
    }
}

static void brightnessCB(CFRunLoopTimerRef t, void *info) {
    (void)t; (void)info;
    setBrightness(gBrightness);
}

// Each command source gets its own buffer, drained without blocking, so a
// payload split across writes never stalls HID servicing or the keepalive.
// Commands are consumed as they complete.
typedef struct {
    uint8_t *buf;
    size_t len, cap;
    int pendKey, pendPng;
    size_t pendLen;
} Source;

static Source gStdin = {0}, gClient = {0};

static void consume(Source *s, size_t n) {
    memmove(s->buf, s->buf + n, s->len - n);
    s->len -= n;
}

static void pump(Source *s) {
    for (;;) {
        if (s->pendLen == 0) {
            uint8_t *nl = memchr(s->buf, '\n', s->len);
            if (!nl) return;
            size_t linelen = (size_t)(nl - s->buf);
            char line[128];
            size_t cp = linelen < sizeof line - 1 ? linelen : sizeof line - 1;
            memcpy(line, s->buf, cp);
            line[cp] = 0;
            consume(s, linelen + 1);

            int key, len, pct;
            char path[256];
            // A path keeps image bytes off the socket entirely. hs.socket
            // reports success on a large write and then drops the connection,
            // so nine tiles of tens of kilobytes each never arrive.
            if (sscanf(line, "paintfile %d %255s", &key, path) == 2 &&
                key >= 0 && key <= 8) {
                FILE *f = pathIsAllowed(path) ? fopen(path, "rb") : NULL;
                if (f) {
                    static uint8_t fbuf[MAX_JPEG];
                    size_t n = fread(fbuf, 1, sizeof fbuf, f);
                    fclose(f);
                    if (n > 0) {
                        CFDataRef jpeg = pngToJpeg(fbuf, n);
                        if (jpeg) {
                            paintKey(key, CFDataGetBytePtr(jpeg),
                                     (size_t)CFDataGetLength(jpeg));
                            CFRelease(jpeg);
                        } else {
                            fprintf(stderr, "paintfile %d: decode failed\n", key);
                        }
                    }
                } else {
                    fprintf(stderr, "paintfile %d: cannot open %s\n", key, path);
                }
            } else if (sscanf(line, "paintpng %d %d", &key, &len) == 2 &&
                key >= 0 && key <= 8 && len > 0 && len <= MAX_JPEG) {
                s->pendKey = key; s->pendLen = (size_t)len; s->pendPng = 1;
            } else if (sscanf(line, "paint %d %d", &key, &len) == 2 &&
                       key >= 0 && key <= 8 && len > 0 && len <= MAX_JPEG) {
                s->pendKey = key; s->pendLen = (size_t)len; s->pendPng = 0;
            } else if (sscanf(line, "brightness %d", &pct) == 1 &&
                       pct >= 0 && pct <= 100) {
                gBrightness = pct;
                setBrightness(pct);
            } else if (strcmp(line, "quit") == 0) {
                CFRunLoopStop(CFRunLoopGetCurrent());
                return;
            }
        } else {
            if (s->len < s->pendLen) return;
            if (s->pendPng) {
                CFDataRef jpeg = pngToJpeg(s->buf, s->pendLen);
                if (jpeg) {
                    paintKey(s->pendKey, CFDataGetBytePtr(jpeg), (size_t)CFDataGetLength(jpeg));
                    CFRelease(jpeg);
                }
            } else {
                paintKey(s->pendKey, s->buf, s->pendLen);
            }
            consume(s, s->pendLen);
            s->pendLen = 0;
        }
    }
}

// Commands are short lines; the largest legitimate payload is one inline
// paintpng. Anything past this is a client that never sends a newline.
#define MAX_SOURCE_BUF (2u * 1024u * 1024u)

// Returns 0 when the source hit EOF.
static int drain(Source *s, int fd) {
    for (;;) {
        if (s->cap - s->len < 65536) {
            if (s->cap >= MAX_SOURCE_BUF) {
                fprintf(stderr, "input buffer hit %u bytes without a newline, dropping\n",
                        MAX_SOURCE_BUF);
                s->len = 0;
                return 0;
            }
            size_t want = s->cap ? s->cap * 2 : 131072;
            uint8_t *grown = realloc(s->buf, want);
            if (!grown) {
                fprintf(stderr, "input buffer realloc failed, dropping\n");
                s->len = 0;
                return 0;
            }
            s->buf = grown;
            s->cap = want;
        }
        ssize_t r = read(fd, s->buf + s->len, s->cap - s->len);
        if (r > 0) { s->len += (size_t)r; continue; }
        if (r == 0) return 0;
        break;                                  // EAGAIN, drained for now
    }
    pump(s);
    return 1;
}

// Stdin closing just detaches stdin. A socket client may still be driving us,
// and a process started in the background gets /dev/null, which is instant EOF.
// Exit is "quit" or a signal.
//
// A pipe is the exception: EOF there means the process holding the write end is
// gone, and for a child that is the client. Lingering would leave the diverted
// controls held with nothing listening, which is exactly the orphan the restart
// path has to clean up. /dev/null and a terminal are not pipes, so the
// background case still behaves as before.
static int stdinIsPipe(void) {
    struct stat st;
    return fstat(0, &st) == 0 && S_ISFIFO(st.st_mode);
}

static void stdinCB(CFFileDescriptorRef f, CFOptionFlags cb, void *info) {
    (void)cb; (void)info;
    if (!drain(&gStdin, 0)) {
        CFFileDescriptorInvalidate(f);
        if (stdinIsPipe() && gClientFd < 0) {
            fprintf(stderr, "stdin closed, exiting\n");
            CFRunLoopStop(CFRunLoopGetMain());
        }
        return;
    }
    CFFileDescriptorEnableCallBacks(f, kCFFileDescriptorReadCallBack);
}

// Tearing the client down has to remove its run loop source as well as
// invalidating the descriptor. Leaving the source scheduled against an
// invalidated descriptor crashes the process on the next disconnect. It also
// must not run inside the client's own callback, so EOF defers it a turn.
static CFRunLoopSourceRef gClientSrc = NULL;
static int gDropPending = 0;

static void teardownClient(void) {
    if (gClientFd >= 0) fprintf(stderr, "client dropped fd=%d\n", gClientFd);
    if (gClientSrc) {
        CFRunLoopRemoveSource(CFRunLoopGetCurrent(), gClientSrc, kCFRunLoopDefaultMode);
        CFRelease(gClientSrc);
        gClientSrc = NULL;
    }
    if (gClientCF) {
        CFFileDescriptorInvalidate(gClientCF);   // closeOnInvalidate closes the fd
        CFRelease(gClientCF);
        gClientCF = NULL;
    }
    gClientFd = -1;
    gClient.len = 0; gClient.pendLen = 0;
}

static void dropClient(void) {
    if (gDropPending) return;
    gDropPending = 1;
    if (gClientCF) CFFileDescriptorDisableCallBacks(gClientCF, kCFFileDescriptorReadCallBack);
    CFRunLoopPerformBlock(CFRunLoopGetCurrent(), kCFRunLoopDefaultMode, ^{
        // A new client may have connected in the meantime, and listenerCB
        // clears the flag when it does. Tearing down here regardless would kill
        // the replacement: it would get its ready line and then silence, which
        // reads as the device having stopped working.
        if (!gDropPending) return;
        gDropPending = 0;
        teardownClient();
    });
    CFRunLoopWakeUp(CFRunLoopGetCurrent());
}

static void clientCB(CFFileDescriptorRef f, CFOptionFlags cb, void *info) {
    (void)cb; (void)info;
    if (!drain(&gClient, gClientFd)) {
        fprintf(stderr, "client EOF\n");
        dropClient();
        return;
    }
    CFFileDescriptorEnableCallBacks(f, kCFFileDescriptorReadCallBack);
}

// One client at a time. A second connection replaces the first, so a
// Hammerspoon reload does not leave the socket wedged.
static void listenerCB(CFFileDescriptorRef f, CFOptionFlags cb, void *info) {
    (void)cb; (void)info;
    int lfd = CFFileDescriptorGetNativeDescriptor(f);
    int fd = accept(lfd, NULL, NULL);
    if (fd >= 0) {
        // Safe to tear down synchronously here: this is the listener's
        // callback, not the outgoing client's.
        gDropPending = 0;
        teardownClient();
        fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
        gClientFd = fd;
        gClientCF = CFFileDescriptorCreate(NULL, fd, true, clientCB, NULL);
        CFFileDescriptorEnableCallBacks(gClientCF, kCFFileDescriptorReadCallBack);
        gClientSrc = CFFileDescriptorCreateRunLoopSource(NULL, gClientCF, 0);
        CFRunLoopAddSource(CFRunLoopGetCurrent(), gClientSrc, kCFRunLoopDefaultMode);
        ssize_t rw = write(fd, gReady, strlen(gReady));
        fprintf(stderr, "client accepted fd=%d ready_write=%zd\n", fd, rw);
    }
    CFFileDescriptorEnableCallBacks(f, kCFFileDescriptorReadCallBack);
}

static int listenOnSocket(const char *path) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof addr);
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, path, sizeof addr.sun_path - 1);
    unlink(path);
    // Bind under a restrictive umask, then pin the mode: the socket carries a
    // command channel to the devices and must not be connectable by other users.
    mode_t prev = umask(0177);
    int rc = bind(fd, (struct sockaddr *)&addr, sizeof addr);
    umask(prev);
    if (rc < 0 || listen(fd, 1) < 0) {
        close(fd);
        return -1;
    }
    if (chmod(path, S_IRUSR | S_IWUSR) < 0) {
        fprintf(stderr, "socket chmod 0600 failed, refusing to serve\n");
        close(fd);
        unlink(path);
        return -1;
    }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
    return fd;
}



// Attaching is factored out so the initial scan and the hot-plug callback share
// it. A Bluetooth device that sleeps and reconnects comes back as a different
// IOHIDDevice, so holding the original reference leaves the helper thinking it
// still has the Dialpad while every event goes nowhere.
static uint8_t gKbuf[64], gDbuf[64];

// Announced on every Keypad attach, not just the first, because a replugged
// Keypad comes up blank and only the client knows what belongs on the keys.
static void announceReady(void) {
    snprintf(gReady, sizeof gReady, "ready %s\n", gDialpad ? "keypad dialpad" : "keypad");
    emit("%s", gReady);
}

static void attachKeypad(IOHIDDeviceRef dev) {
    if (IOHIDDeviceOpen(dev, kIOHIDOptionsTypeNone) != kIOReturnSuccess) return;
    gKeypad = dev;
    IOHIDDeviceRegisterInputReportCallback(dev, gKbuf, sizeof gKbuf, keypadCB, NULL);
    IOHIDDeviceScheduleWithRunLoop(dev, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode);
    send11(dev, IDX_0008, 1, 0x0b, 0xb8, 0x00);
    send11(dev, IDX_1B04, 3, 0x01, 0xa1, 0x03);
    send11(dev, IDX_1B04, 3, 0x01, 0xa2, 0x03);
    setBrightness(gBrightness);
    fprintf(stderr, "keypad attached\n");
    announceReady();
}

static void attachDialpad(IOHIDDeviceRef dev) {
    IOReturn rc = IOHIDDeviceOpen(dev, kIOHIDOptionsTypeNone);
    if (rc != kIOReturnSuccess) {
        fprintf(stderr, "dialpad open failed rc=0x%08x%s\n", rc,
                rc == kIOReturnNotPermitted ? ", check Input Monitoring" : "");
        return;
    }
    gDialpad = dev;
    IOHIDDeviceRegisterInputReportCallback(dev, gDbuf, sizeof gDbuf, dialpadCB, NULL);
    IOHIDDeviceScheduleWithRunLoop(dev, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode);
    for (int i = 0; i < ROLLERS; i++) send11(dev, IDX_4610, 3, (uint8_t)i, 0x01, 0x00);
    for (int i = 0; i < 4; i++)
        send11(dev, IDX_1B04_DIAL, 3, (uint8_t)(kDialCids[i] >> 8),
               (uint8_t)(kDialCids[i] & 0xFF), 0x03);
    fprintf(stderr, "dialpad attached\n");
    // No re-announce: the Dialpad wakes from Bluetooth sleep often, and a ready
    // line means "repaint everything" to the client.
    snprintf(gReady, sizeof gReady, "ready %s\n", gKeypad ? "keypad dialpad" : "dialpad");
}

static int32_t devicePid(IOHIDDeviceRef dev) {
    CFTypeRef p = IOHIDDeviceGetProperty(dev, CFSTR(kIOHIDProductIDKey));
    int32_t pid = -1;
    if (p) CFNumberGetValue((CFNumberRef)p, kCFNumberSInt32Type, &pid);
    return pid;
}

static void deviceAdded(void *c, IOReturn r, void *s, IOHIDDeviceRef dev) {
    (void)c; (void)r; (void)s;
    int32_t pid = devicePid(dev);
    if (pid == PID_KEYPAD && dev != gKeypad) attachKeypad(dev);
    else if (pid == PID_DIALPAD && dev != gDialpad) attachDialpad(dev);
}

static void deviceRemoved(void *c, IOReturn r, void *s, IOHIDDeviceRef dev) {
    (void)c; (void)r; (void)s;
    // Held state cannot survive the device. A client waiting on a release would
    // never get one, and on reconnect the equality checks would swallow an
    // identical first press.
    if (dev == gKeypad) {
        gKeypad = NULL;
        if (gHeldKey) { gHeldKey = 0; emit("key up\n"); }
        gHeldCid = 0;
        fprintf(stderr, "keypad removed\n");
    }
    if (dev == gDialpad) {
        gDialpad = NULL;
        int any = 0;
        for (int i = 0; i < 4; i++) {
            int n = dialIndex(gHeldDial[i]);
            gHeldDial[i] = 0;
            if (n) { any = 1; emit("dialkey %d up\n", n); }
        }
        if (any) emit("dialkey up\n");
        fprintf(stderr, "dialpad removed\n");
    }
}

// Divert lives on the device, so exiting without clearing it leaves the nav
// buttons, dial buttons and rollers dead until the device power cycles. Every
// exit path has to come through here, not just the normal one.
static void restoreDevices(void) {
    send11(gKeypad, IDX_1B04, 3, 0x01, 0xa1, 0x02);
    send11(gKeypad, IDX_1B04, 3, 0x01, 0xa2, 0x02);
    if (gDialpad) {
        for (int i = 0; i < ROLLERS; i++) send11(gDialpad, IDX_4610, 3, (uint8_t)i, 0x00, 0x00);
        for (int i = 0; i < 4; i++)
            send11(gDialpad, IDX_1B04_DIAL, 3, (uint8_t)(kDialCids[i] >> 8),
                   (uint8_t)(kDialCids[i] & 0xFF), 0x02);
        IOHIDDeviceClose(gDialpad, kIOHIDOptionsTypeNone);
        gDialpad = NULL;
    }
    if (gKeypad) {
        IOHIDDeviceClose(gKeypad, kIOHIDOptionsTypeNone);
        gKeypad = NULL;
    }
}

int main(void) {
    // Before the handlers, so a signal arriving early still has somewhere to go.
    if (pipe(gSigPipe) < 0) { perror("pipe"); return 1; }
    fcntl(gSigPipe[0], F_SETFL, fcntl(gSigPipe[0], F_GETFL, 0) | O_NONBLOCK);
    fcntl(gSigPipe[1], F_SETFL, fcntl(gSigPipe[1], F_GETFL, 0) | O_NONBLOCK);
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, onSignal);
    signal(SIGINT, onSignal);
    fcntl(0, F_SETFL, fcntl(0, F_GETFL, 0) | O_NONBLOCK);

    CFFileDescriptorRef sigCF = CFFileDescriptorCreate(NULL, gSigPipe[0], false, sigPipeCB, NULL);
    CFFileDescriptorEnableCallBacks(sigCF, kCFFileDescriptorReadCallBack);
    CFRunLoopSourceRef sigSrc = CFFileDescriptorCreateRunLoopSource(NULL, sigCF, 0);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), sigSrc, kCFRunLoopDefaultMode);
    CFRelease(sigSrc);

    // Match Logitech only. Matching NULL asks to open every HID device on the
    // system, keyboard included, which is TCC-gated and normally fails. With
    // Input Monitoring granted it succeeds, and grabbing every device is enough
    // to make the keyboard stutter.
    IOHIDManagerRef mgr = IOHIDManagerCreate(kCFAllocatorDefault, kIOHIDOptionsTypeNone);
    int32_t wantVid = VID;
    CFNumberRef vidNum = CFNumberCreate(NULL, kCFNumberSInt32Type, &wantVid);
    const void *mk[] = { CFSTR(kIOHIDVendorIDKey) };
    const void *mv[] = { vidNum };
    CFDictionaryRef match = CFDictionaryCreate(NULL, mk, mv, 1,
                                               &kCFTypeDictionaryKeyCallBacks,
                                               &kCFTypeDictionaryValueCallBacks);
    IOHIDManagerSetDeviceMatching(mgr, match);
    CFRelease(match); CFRelease(vidNum);
    IOHIDManagerRegisterDeviceMatchingCallback(mgr, deviceAdded, NULL);
    IOHIDManagerRegisterDeviceRemovalCallback(mgr, deviceRemoved, NULL);
    IOHIDManagerScheduleWithRunLoop(mgr, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode);
    IOHIDManagerOpen(mgr, kIOHIDOptionsTypeNone);

    // The matching callback fires for devices already present, so the initial
    // scan and later arrivals both go through the same path. A Dialpad that is
    // asleep now simply attaches when it wakes, with no restart.
    CFRunLoopRunInMode(kCFRunLoopDefaultMode, 0.5, false);
    // Not fatal. Exiting here abandons a Dialpad the scan just diverted, and
    // the supervisor's restart loop then re-diverts and re-abandons it every
    // few seconds forever. Waiting for the hot-plug callback costs nothing and
    // covers booting before USB enumeration finishes.
    if (!gKeypad) fprintf(stderr, "keypad not found, waiting\n");

    // The device asks for a ping every 3000 ms. Pinging at exactly 3.0 s leaves
    // no margin for timer jitter, and the firmware reclaiming the panel may be
    // it deciding the host went quiet.
    const char *ki = getenv("MXCC_KEEPALIVE_INTERVAL");
    double ksecs = ki ? atof(ki) : 1.0;
    CFRunLoopTimerRef ka = CFRunLoopTimerCreate(NULL, CFAbsoluteTimeGetCurrent() + ksecs,
                                                ksecs, 0, 0, keepaliveCB, NULL);
    CFRunLoopAddTimer(CFRunLoopGetCurrent(), ka, kCFRunLoopDefaultMode);
    // Re-asserting brightness is what keeps the host owning the display. Let it
    // lapse and the firmware takes the panel back to its idle screen, after
    // which paints are ignored.
    // Brightness interval in seconds, 0 to set it once at startup and leave it.
    // Re-asserting it appears to blank and relight the panel, which reads as a
    // flash, so it is worth being able to turn off while the refresh timer is
    // the thing holding the display.
    const char *bi = getenv("MXCC_BRIGHTNESS_INTERVAL");
    double bsecs = bi ? atof(bi) : 0.0;
    if (bsecs > 0) {
        CFRunLoopTimerRef bt = CFRunLoopTimerCreate(NULL, CFAbsoluteTimeGetCurrent() + bsecs,
                                                    bsecs, 0, 0, brightnessCB, NULL);
        CFRunLoopAddTimer(CFRunLoopGetCurrent(), bt, kCFRunLoopDefaultMode);
    }
    // Repaint interval in seconds, 0 to disable. Repainting fights the firmware
    // rather than preventing it, so it is a fallback, not the fix.
    const char *ri = getenv("MXCC_REFRESH_INTERVAL");
    double rsecs = ri ? atof(ri) : 4.0;
    if (rsecs > 0) {
        CFRunLoopTimerRef rt = CFRunLoopTimerCreate(NULL, CFAbsoluteTimeGetCurrent() + rsecs,
                                                    rsecs, 0, 0, refreshCB, NULL);
        CFRunLoopAddTimer(CFRunLoopGetCurrent(), rt, kCFRunLoopDefaultMode);
    }

    // Unconditional. The heartbeat is how a client tells a dead socket from an
    // idle one, so it must not depend on the repaint timer being enabled.
    CFRunLoopTimerRef pt = CFRunLoopTimerCreate(NULL, CFAbsoluteTimeGetCurrent() + 10.0,
                                                10.0, 0, 0, pingCB, NULL);
    CFRunLoopAddTimer(CFRunLoopGetCurrent(), pt, kCFRunLoopDefaultMode);

    CFFileDescriptorRef fd = CFFileDescriptorCreate(NULL, 0, false, stdinCB, NULL);
    CFFileDescriptorEnableCallBacks(fd, kCFFileDescriptorReadCallBack);
    CFRunLoopSourceRef src = CFFileDescriptorCreateRunLoopSource(NULL, fd, 0);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), src, kCFRunLoopDefaultMode);

    // hs.task:setInput only delivers before start(), so Hammerspoon cannot use
    // stdin for a long-lived command stream. The socket is the channel it uses.
    const char *sockPath = getenv("MXCC_SOCKET");
    char sockDefault[PATH_MAX];
    if (!sockPath) {
        // Not /tmp: that directory is world-writable, so the pre-bind unlink is
        // a symlink-swap window and the socket is only as private as the umask.
        //
        // Failing here is not fatal: stdin and stdout still work, and returning
        // would leave both devices diverted with nothing listening.
        const char *home = getenv("HOME");
        char dir[PATH_MAX];
        if (!home) {
            fprintf(stderr, "HOME unset, socket disabled\n");
        } else {
            snprintf(dir, sizeof dir, "%s/Library/Application Support/mx-creative-console", home);
            if (mkdir(dir, S_IRWXU) < 0 && errno != EEXIST) {
                fprintf(stderr, "cannot create %s: %s, socket disabled\n", dir, strerror(errno));
            } else {
                chmod(dir, S_IRWXU);
                snprintf(sockDefault, sizeof sockDefault, "%s/helper.sock", dir);
                sockPath = sockDefault;
            }
        }
    }
    int lfd = sockPath ? listenOnSocket(sockPath) : -1;
    if (lfd < 0) {
        if (sockPath) fprintf(stderr, "socket %s failed\n", sockPath);
    } else {
        CFFileDescriptorRef lcf = CFFileDescriptorCreate(NULL, lfd, true, listenerCB, NULL);
        CFFileDescriptorEnableCallBacks(lcf, kCFFileDescriptorReadCallBack);
        CFRunLoopSourceRef ls = CFFileDescriptorCreateRunLoopSource(NULL, lcf, 0);
        CFRunLoopAddSource(CFRunLoopGetCurrent(), ls, kCFRunLoopDefaultMode);
        CFRelease(ls);
    }

    // attachKeypad already announced if the scan found it; otherwise the
    // hot-plug callback announces whenever it shows up.
    CFRunLoopRun();
    if (sockPath) unlink(sockPath);
    restoreDevices();
    return 0;
}
